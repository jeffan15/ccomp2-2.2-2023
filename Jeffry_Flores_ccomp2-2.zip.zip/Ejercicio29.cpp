#include <iostream>
using namespace std;

int main(){
    cout << "Largo de cara del cubo(cm)\t" << "superficie area del cubo(cm^2)\t" << "volumen del cubo(cm^3)\t" << endl;
    cout << 0 << "\t\t\t\t" << 6*(0*0) << "\t\t\t\t" << 0*0*0 << endl;
    cout << 1 << "\t\t\t\t" << 6*(1*1) << "\t\t\t\t" << 1*1*1 << endl;
    cout << 2 << "\t\t\t\t" << 6*(2*2) << "\t\t\t\t" << 2*2*2 << endl;
    cout << 3 << "\t\t\t\t" << 6*(3*3) << "\t\t\t\t" << 3*3*3 << endl;
    cout << 4 << "\t\t\t\t" << 6*(4*4) << "\t\t\t\t" << 4*4*4 << endl;
    return 0;
}