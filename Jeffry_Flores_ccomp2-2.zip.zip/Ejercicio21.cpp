# include <iostream>
using namespace std;

int main()
{
    cout << "  ccc" << "  +  " << "    +  "<< endl;
    cout << " c   " << "  +  " << "    +  "<< endl;
    cout << "c    " << "+++++" << "  +++++"<< endl;
    cout << " c   " << "  +  " << "    +  "<< endl;
    cout << "  ccc" << "  +  " << "    +  "<< endl;
    return 0;
}