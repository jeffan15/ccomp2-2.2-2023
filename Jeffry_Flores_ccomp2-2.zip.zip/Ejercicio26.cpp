# include <iostream>
using namespace std;

int main (){
    cout << "* * * * * * * *\n * * * * * * * *" << endl;
    cout << "* * * * * * * *\n * * * * * * * *" << endl;
    cout << "* * * * * * * *\n * * * * * * * *" << endl;
    cout << "* * * * * * * *\n * * * * * * * *" << endl;
    return 0;
}